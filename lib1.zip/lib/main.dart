import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'app/theme.dart';
import 'features/trajet/services/trajet_service.dart';
import 'screens/accueil_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('fr_FR', null);

  // Module Trajets : lit les trajets dans SQLite avant d'afficher l'accueil
  await TrajetService.instance.charger();

  runApp(const CovoiturageApp());
}

class CovoiturageApp extends StatelessWidget {
  const CovoiturageApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Covoiturage Étudiant',
      // Couleurs de l'application à partir du bleu de la charte (app/theme.dart)
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primaire),
      ),
      home: const AccueilPage(),
    );
  }
}